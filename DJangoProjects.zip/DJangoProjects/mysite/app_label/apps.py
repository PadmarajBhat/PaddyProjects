from django.apps import AppConfig


class AppLabelConfig(AppConfig):
    name = 'app_label'
