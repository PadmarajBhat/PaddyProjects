pyramid_wut4lunch README
==================

Getting Started
---------------

- cd <directory containing this file>

- $VENV/bin/python setup.py develop

- $VENV/bin/initialize_pyramid_wut4lunch_db development.ini

- $VENV/bin/pserve development.ini

