## How to run

```
python setup.py develop

# Set up the database
python pyramid_wut4lunch/scripts/initializedb.py development.ini

pserve development.ini

# go to http://localhost:6543/
```
