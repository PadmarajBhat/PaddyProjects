## How to run

```
pip install -r requirements.txt

python manage.py migrate

python manage.py runserver

# go to http://localhost:8000/
```
