from django.contrib import admin

from .models import Lunch
# Register your models here.

admin.site.register(Lunch)
