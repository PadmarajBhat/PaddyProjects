from django.conf.urls import include, url
from django.contrib import admin
#import wut4lu#ch.views

urlpatterns = [
    # Examples:
    # url(r'^$', 'hello_django.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    url(r'^index/', include('wut4lunch.urls'), name='home'),
    url(r'^newlunch/', include('wut4lunch.urls'), name='newlunch'),
]
