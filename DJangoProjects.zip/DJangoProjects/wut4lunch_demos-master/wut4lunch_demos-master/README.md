These applications accompany an article on AirPair.com comparing the Flask,
Django, and Pyramid web frameworks.

These snippets are licensed under the GPLv3 license, see the `LICENSE` file for
details.
